"""Elite Dangerous plugin — lifecycle only.

Starts/stops the connector on ``start()``/``stop()``.  ``poll()``
returns current state for Iris; ``snapshot()`` adds debug/event-log
data for the journal explorer.
"""

import logging
import threading
import time

from display_priority import (
    PRIO_PERSIST_REMINDER,
    PRIO_PERSIST_URGENT,
    PRIO_PERSIST_NORMAL,
    PRIO_PERSIST_MINOR,
)
from .connector import EDConnector

log = logging.getLogger("iris.plugins.elite_dangerous")

FUEL_LOW_PCT = 30.0

# Critical alert colour (red flashing background). This is the ALERT channel —
# distinct from the per-button STATUS border colour the panel derives from the
# button profile. Kept as a single constant here: once the core exposes a
# semantic (colour-less) alert API, this constant can be dropped.
ALERT_COLOR = "#ff3355"

LAYOUT = [
    {"title": "Navigation", "fields": [
        {"key": "system", "label": "System"},
        {"key": "body", "label": "Body"},
        {"key": "body_type", "label": "Type"},
        {"key": "allegiance", "label": "Allegiance"},
        {"key": "economy", "label": "Economy"},
        {"key": "government", "label": "Government"},
        {"key": "security", "label": "Security"},
        {"key": "population", "label": "Population"},
    ]},
    {"title": "Commander", "fields": [
        {"key": "commander", "label": "Name"},
        {"key": "credits", "label": "Credits"},
        {"key": "rank_combat", "label": "Combat Rank"},
        {"key": "progress_combat", "label": "Combat Progress"},
        {"key": "rank_trade", "label": "Trade Rank"},
        {"key": "progress_trade", "label": "Trade Progress"},
        {"key": "rank_explore", "label": "Explore Rank"},
        {"key": "progress_explore", "label": "Explore Progress"},
        {"key": "rank_empire", "label": "Empire"},
        {"key": "rank_federation", "label": "Federation"},
    ]},
    {"title": "Ship", "fields": [
        {"key": "ship", "label": "Ship"},
        {"key": "hull_health", "label": "Hull"},
        {"key": "shields_up", "label": "Shields", "source": "status", "display": "up_down"},
        {"key": "fuel_level", "label": "Fuel"},
        {"key": "fuel_capacity", "label": "Capacity"},
        {"key": "fuel_scooped", "label": "Scooped"},
        {"key": "cargo", "label": "Cargo"},
        {"key": "docked", "label": "Docked", "source": "status", "display": "yes_no"},
        {"key": "landed", "label": "Landed", "source": "status", "display": "yes_no"},
        {"key": "landing_gear", "label": "Landing Gear", "source": "status", "display": "down_up"},
        {"key": "hardpoints", "label": "Hardpoints", "source": "status", "display": "deployed_retracted"},
        {"key": "cargo_scoop", "label": "Cargo Scoop", "source": "status", "display": "deployed_retracted"},
        {"key": "flight_assist", "label": "Flight Assist", "source": "status", "display": "on_off"},
        {"key": "silent_running", "label": "Silent Running", "source": "status", "display": "on_off"},
        {"key": "lights_on", "label": "Lights", "source": "status", "display": "on_off"},
        {"key": "night_vision", "label": "Night Vision", "source": "status", "display": "on_off"},
        {"key": "in_srv", "label": "In SRV", "source": "status", "display": "yes_no"},
        {"key": "in_fighter", "label": "In Fighter", "source": "status", "display": "yes_no"},
        {"key": "on_foot", "label": "On Foot", "source": "status", "display": "yes_no"},
        {"key": "taxi", "label": "Apex Taxi", "source": "status", "display": "yes_no"},
        {"key": "multicrew", "label": "Multicrew", "source": "status", "display": "yes_no"},
        {"key": "supercruise", "label": "Supercruise", "source": "status", "display": "yes_no"},
    ]},
    {"title": "Combat", "fields": [
        {"key": "target_ship", "label": "Target"},
        {"key": "bounty_reward", "label": "Bounty Reward"},
        {"key": "mission", "label": "Mission"},
        {"key": "mission_reward", "label": "Mission Reward"},
        {"key": "mass_locked", "label": "Mass Lock", "source": "status", "display": "yes_no"},
        {"key": "wing_visible", "label": "Wing", "source": "status", "display": "yes_no"},
        {"key": "last_repair", "label": "Last Repair"},
        {"key": "last_repair_cost", "label": "Repair Cost"},
    ]},
    {"title": "Exploration", "fields": [
        {"key": "jump_type", "label": "Jump Type"},
        {"key": "fsd_charging", "label": "FSD Charging", "source": "status", "display": "yes_no"},
        {"key": "fsd_cooldown", "label": "FSD Cooldown", "source": "status", "display": "yes_no"},
        {"key": "fsd_jump", "label": "FSD Jump", "source": "status", "display": "yes_no"},
        {"key": "hyperdrive", "label": "Hyperdrive", "source": "status", "display": "yes_no"},
        {"key": "glide", "label": "Glide", "source": "status", "display": "yes_no"},
        {"key": "last_scan", "label": "Last Scan"},
        {"key": "scan_distance", "label": "Scan Distance"},
        {"key": "system_scan_pct", "label": "System Scan"},
        {"key": "scooping_fuel", "label": "Fuel Scooping", "source": "status", "display": "yes_no"},
    ]},
    {"title": "Powerplay", "fields": [
        {"key": "powerplay_power", "label": "Power"},
        {"key": "powerplay_rank", "label": "Rank"},
        {"key": "powerplay_merits", "label": "Merits"},
    ]},
    {"title": "Fleet Carrier", "fields": [
        {"key": "carrier_name", "label": "Name"},
        {"key": "carrier_callsign", "label": "Callsign"},
    ]},
]


class Plugin:
    name = "elite_dangerous"
    display_name = "Elite Dangerous"

    def __init__(self, cfg, serial_sender=None, overlays=None):
        self._connector = EDConnector()
        self._serial = serial_sender
        self._cfg = cfg
        self.overlays = overlays
        self._running = False
        self._thread = None
        self._last_system = None

    def start(self):
        self._connector.connect()
        self._running = True
        self._thread = threading.Thread(
            target=self._watch_system_changes,
            daemon=True,
            name="ed-system-watch",
        )
        self._thread.start()
        self._ship_thread = threading.Thread(
            target=self._watch_ship_state,
            daemon=True,
            name="ed-ship-watch",
        )
        self._ship_thread.start()
        self._ensure_default_profile()
        log.info("elite_dangerous plugin started")

    def _ensure_default_profile(self):
        """Install a default Elite Dangerous button-box profile if one doesn't exist.

        Checks panel_profiles for any profile whose exe or name matches Elite
        Dangerous.  If none is found, injects a fully-configured 12-slot profile
        so the user has a ready-to-use button box the moment the plugin loads.
        Does nothing if a matching profile already exists.
        """
        try:
            from config import save_config
            cfg = self._cfg
            if not isinstance(cfg, dict):
                return

            profiles = cfg.get("panel_profiles") or []
            ed_exe = "EliteDangerous64.exe"

            # Already exists? Leave it alone.
            for p in profiles:
                if not isinstance(p, dict):
                    continue
                exe = (p.get("exe") or "").lower()
                name = (p.get("name") or "").lower()
                if "elite" in exe or "elite" in name or "EliteDangerous64" in (p.get("exe") or ""):
                    return

            default_board = [
                {
                    "type": "TOGGLE",
                    "name": "Landing Gear",
                    "icon": "airplane-landing",
                    "icon_off": "airplane-takeoff",
                    "color": "#48b2e9",
                    "plugin": "elite_dangerous",
                    "button_id": "landing_gear",
                    "widget_type": "status_toggle",
                    "state_key": "landing_gear",
                    "labels": {"on": "DOWN", "off": "UP"},
                    "colors": {"on": "#48b2e9", "off": "#444444"},
                    "hotkey": "L",
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Cargo Scoop",
                    "icon": "bag-personal",
                    "color": "#48b2e9",
                    "plugin": "elite_dangerous",
                    "button_id": "cargo_scoop",
                    "widget_type": "status_toggle",
                    "state_key": "cargo_scoop",
                    "labels": {"on": "DEPLOYED", "off": "RETRACTED"},
                    "colors": {"on": "#48b2e9", "off": "#444444"},
                    "hotkey": "Home",
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Flight Assist",
                    "icon": "steering",
                    "color": "#48b2e9",
                    "plugin": "elite_dangerous",
                    "button_id": "flight_assist",
                    "widget_type": "status_toggle",
                    "state_key": "flight_assist",
                    "labels": {"on": "ON", "off": "OFF"},
                    "colors": {"on": "#48b2e9", "off": "#444444"},
                    "hotkey": "Z",
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Ship Lights",
                    "icon": "flare",
                    "color": "#48b2e9",
                    "plugin": "elite_dangerous",
                    "button_id": "lights",
                    "widget_type": "status_toggle",
                    "state_key": "lights_on",
                    "labels": {"on": "ON", "off": "OFF"},
                    "colors": {"on": "#48b2e9", "off": "#444444"},
                    "hotkey": "Insert",
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Hardpoints",
                    "icon": "crosshairs",
                    "color": "#48b2e9",
                    "plugin": "elite_dangerous",
                    "button_id": "hardpoints",
                    "widget_type": "status_toggle",
                    "state_key": "hardpoints",
                    "labels": {"on": "DEPLOYED", "off": "RETRACTED"},
                    "colors": {"on": "#48b2e9", "off": "#444444"},
                    "hotkey": "U",
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Night Vision",
                    "icon": "eye",
                    "color": "#48b2e9",
                    "plugin": "elite_dangerous",
                    "button_id": "night_vision",
                    "widget_type": "status_toggle",
                    "state_key": "night_vision",
                    "labels": {"on": "ON", "off": "OFF"},
                    "colors": {"on": "#48b2e9", "off": "#444444"},
                    "hotkey": "N",
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Silent Running",
                    "icon": "ghost",
                    "color": "#48b2e9",
                    "plugin": "elite_dangerous",
                    "button_id": "silent_running",
                    "widget_type": "status_toggle",
                    "state_key": "silent_running",
                    "labels": {"on": "ACTIVE", "off": "OFF"},
                    "colors": {"on": "#48b2e9", "off": "#444444"},
                    "hotkey": "Delete",
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Supercruise",
                    "icon": "rocket-launch",
                    "color": "#48b2e9",
                    "plugin": "elite_dangerous",
                    "button_id": "supercruise",
                    "widget_type": "status_toggle",
                    "state_key": "supercruise",
                    "labels": {"on": "ACTIVE", "off": "IDLE"},
                    "colors": {"on": "#48b2e9", "off": "#444444"},
                    "hotkey": "J",
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Shields",
                    "icon": "shield",
                    "color": "#00ff88",
                    "plugin": "elite_dangerous",
                    "button_id": "shields",
                    "widget_type": "display",
                    "state_key": "shields_up",
                    "labels": {"on": "ONLINE", "off": "DOWN"},
                    "colors": {"on": "#00ff88", "off": "#ff3355"},
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Mass Lock",
                    "icon": "weight",
                    "color": "#ff3355",
                    "plugin": "elite_dangerous",
                    "button_id": "mass_lock",
                    "widget_type": "display",
                    "state_key": "mass_locked",
                    "labels": {"on": "LOCKED", "off": "CLEAR"},
                    "colors": {"on": "#ff3355", "off": "#00ff88"},
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "FSD Charge",
                    "icon": "speedometer",
                    "color": "#ffaa00",
                    "plugin": "elite_dangerous",
                    "button_id": "fsd_status",
                    "widget_type": "display",
                    "state_key": "fsd_charging",
                    "labels": {"on": "CHARGING", "off": "READY"},
                    "colors": {"on": "#ffaa00", "off": "#555555"},
                    "show_name": True, "show_icon": True, "show_state": True,
                },
                {
                    "type": "TOGGLE",
                    "name": "Fuel Scoop",
                    "icon": "gas-station",
                    "color": "#ffee00",
                    "plugin": "elite_dangerous",
                    "button_id": "fuel_scoop",
                    "widget_type": "display",
                    "state_key": "scooping_fuel",
                    "labels": {"on": "SCOOPING", "off": "IDLE"},
                    "colors": {"on": "#ffee00", "off": "#555555"},
                    "show_name": True, "show_icon": True, "show_state": True,
                },
            ]

            new_profile = {
                "id": "prof_elite_dangerous",
                "name": "Elite Dangerous",
                "exe": ed_exe,
                "enabled": True,
                "board": default_board,
            }

            profiles.append(new_profile)
            cfg["panel_profiles"] = profiles
            save_config(cfg)
            log.info("[ed] installed default button-box profile")

        except Exception as e:
            log.warning("[ed] could not install default profile: %s", e)


    def stop(self):
        self._running = False
        self._connector.disconnect()
        if self._serial:
            if hasattr(self._serial, "release_progress_prefix"):
                self._serial.release_progress_prefix("ed.")
            if hasattr(self._serial, "clear_display_prefix"):
                self._serial.clear_display_prefix("ed.")

    def poll(self):
        """Lightweight live state for UI polling — no event log, no layout."""
        return {
            "available": self._connector.available,
            "state": self._connector.live_state(),
            "status": self._connector.status(),
        }

    def _watch_system_changes(self):
        """Background thread: show hero overlay when the system changes."""
        while self._running:
            try:
                state = self._connector.live_state()
                system = state.get("system", "")
                if system:
                    if self._last_system is None:
                        # First reading: just set the baseline, no overlay.
                        self._last_system = system
                    elif system != self._last_system:
                        self._last_system = system
                        self._show_system_hero(state)
            except Exception as e:
                log.warning("[ed] system watch error: %s", e)
            time.sleep(1.0)

    def _show_system_hero(self, state):
        """Render a hero overlay and send the system to the hardware display."""
        if not self.overlays:
            return
        system = state.get("system", "")
        if not system:
            return

        population = state.get("population", "Unknown")
        fields = [
            ("Economy", state.get("economy", "Unknown")),
            ("Government", state.get("government", "Unknown")),
            ("Security", state.get("security", "Unknown")),
            ("Allegiance", state.get("allegiance", "Unknown")),
        ]

        self.overlays.hero(
            title=system,
            subtitle=f"Population: {population}",
            fields=fields,
            duration=6,
        )

        if self._serial:
            self._serial.notify(
                "ed.system",
                system,
                f"Population: {population}",
            )

        log.info("[ed] system arrival: %s", system)

    def _watch_ship_state(self):
        """Push gear/hardpoints/cargo-hatch transitions and the fuel
        progress bar to the matrix display."""
        ship_labels = {
            "landing_gear": ("GEAR", "DOWN", "UP"),
            "hardpoints": ("HARDPOINTS", "DEPLOYED", "STOWED"),
            "cargo_scoop": ("CARGO HATCH", "OPEN", "CLOSED"),
        }
        prev = {}
        shield_alert_active = False
        while self._running:
            try:
                st = self._connector.status()
            except Exception as e:
                log.warning("[ed] ship state error: %s", e)
                time.sleep(1.0)
                continue
            for key, (label, on_msg, off_msg) in ship_labels.items():
                cur = st.get(key)
                if cur is None:
                    continue
                last = prev.get(key)
                if last is not None and cur != last and self._serial:
                    # Determine good vs bad status
                    if key == "landing_gear":
                        ev_status = "good" if cur else "bad"  # DOWN is safe (good), UP is retracted (bad)
                    elif key == "hardpoints":
                        ev_status = "bad" if cur else "good"  # DEPLOYED is combat alert (bad), STOWED is safe (good)
                    else:
                        ev_status = "good"

                    if hasattr(self._serial, "event"):
                        self._serial.event(
                            f"ed.{key}",
                            label,
                            on_msg if cur else off_msg,
                            status=ev_status,
                        )
                    else:
                        self._serial.notify(
                            f"ed.{key}",
                            label,
                            on_msg if cur else off_msg,
                        )
                prev[key] = cur

            # Shield-down alert: STATE-driven, not edge-triggered. While the
            # status reports shields DOWN the alert is active — sent once per
            # episode, re-armed when shields come back online. The connector
            # keeps shields_up authoritative from the journal ShieldState event,
            # so a stale Status.json flag can't re-fire it during recovery.
            shields = st.get("shields_up")
            if shields is not None:
                if shields is False:
                    if not shield_alert_active:
                        self._alert_shields_down()
                        self._set_shields_warning()
                        shield_alert_active = True
                else:
                    if shield_alert_active:
                        shield_alert_active = False
                        self._clear_shields_warning()

            self._update_progress_bar(st)
            time.sleep(0.5)

    def _alert_shields_down(self):
        """Red rapid-flash alert when the ship shield generator fails."""
        if not self._serial:
            return
        try:
            if hasattr(self._serial, "send_alert"):
                self._serial.send_alert(
                    "SHIELDS DOWN",
                    "Shield generator has failed",
                    key="ed.shields",
                )
            else:
                self._serial.notify(
                    "ed.shields",
                    "SHIELDS DOWN",
                    "Shield generator has failed",
                    theme="alert",
                )
            log.info("[ed] shields down alert sent")
        except Exception as e:
            log.warning("[ed] shield alert error: %s", e)

    def _set_shields_warning(self):
        """Flag the Shields button red while the shield generator is down.

        The warning colour overrides the button's normal on/off colour; when it
        is cleared the button returns to its previous saved value.
        """
        if not self._serial:
            return
        try:
            if hasattr(self._serial, "set_warning"):
                self._serial.set_warning(
                    "elite_dangerous:shields",
                    color=ALERT_COLOR,
                    message="SHIELDS DOWN",
                )
        except Exception as e:
            log.warning("[ed] shield warning error: %s", e)

    def _clear_shields_warning(self):
        """Turn the warning off; the button returns to its saved colour."""
        if not self._serial:
            return
        try:
            if hasattr(self._serial, "clear_warning"):
                self._serial.clear_warning("elite_dangerous:shields")
            if hasattr(self._serial, "clear_display"):
                self._serial.clear_display("ed.shields")
        except Exception as e:
            log.warning("[ed] shield warning clear error: %s", e)

    def _fuel_percent(self):
        """Return fuel % (0-100) from journal fuel tons, or None if unknown."""
        try:
            state = self._connector.live_state()
            level = state.get("fuel_level")
            cap = state.get("fuel_capacity")
            if not level or not cap:
                return None
            cap_f = float(cap)
            if cap_f <= 0:
                return None
            pct = float(level) / cap_f * 100.0
            return max(0.0, min(100.0, pct))
        except Exception:
            return None

    def _update_progress_bar(self, status):
        """Drive the matrix progress bar via display claims.

        Ladder: STATION (docked, urgent) > GEAR (gear down) > LIMPETS
        (reminder, 3s every 10s while docked) > FUEL (scooping / low).
        The station claim is persistent while docked and outranks gear, so
        gear "naturally resumes" when the ship undocks.  Nothing is claimed
        when the game is not running, so the bar clears shortly after the
        game exits (no stale gear from a previous session).
        """
        if not self._serial:
            return

        if not self._connector.game_running():
            if hasattr(self._serial, "release_progress_prefix"):
                self._serial.release_progress_prefix("ed.")
            else:
                for cid in ("ed.station", "ed.limpets", "ed.gear", "ed.fuel"):
                    self._serial.release_progress(cid)
            if hasattr(self._serial, "clear_display_prefix"):
                self._serial.clear_display_prefix("ed.")
            return

        fuel_pct = self._fuel_percent()
        scooping = bool(status.get("scooping_fuel", False))

        if bool(status.get("docked", False)):
            station = self._connector.live_state().get("body", "").strip() or "STATION"
            self._serial.claim_progress(
                "ed.station", PRIO_PERSIST_URGENT, station, 100)
            self._serial.remind_progress(
                "ed.limpets", PRIO_PERSIST_REMINDER, "LIMPETS", 100,
                on_s=3.0, period_s=10.0)
        else:
            self._serial.release_progress("ed.station")
            self._serial.release_progress("ed.limpets")

        if bool(status.get("landing_gear", False)):
            self._serial.claim_progress(
                "ed.gear", PRIO_PERSIST_NORMAL, "GEAR", 100)
        else:
            self._serial.release_progress("ed.gear")

        if fuel_pct is not None and (scooping or fuel_pct < FUEL_LOW_PCT):
            name = "SCOOPING" if scooping else "LOW FUEL"
            self._serial.claim_progress(
                "ed.fuel", PRIO_PERSIST_MINOR, name, int(round(fuel_pct)))
        else:
            self._serial.release_progress("ed.fuel")

    def snapshot(self):
        """Full debug payload for journal explorer / diagnostics."""
        return {
            "available": self._connector.available,
            "state": self._connector.state(),
            "status": self._connector.status(),
            "layout": LAYOUT,
            "events_raw": self._connector.event_log()[-50:],
        }
